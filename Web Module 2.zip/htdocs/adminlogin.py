#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()
id=form.getvalue("uid")
pas=form.getvalue("psw")

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

curs.execute("select * from users where AdminID='%s' and password='%s';" %(id, pas))
rec=curs.fetchone()

if rec:
    print("<head>")
    print("<script>")
    print("alert('Login Sucessful....')")
    print("</script>")
    print("<head>")
    print("<meta http-equiv='refresh' content='0; url=options.html'/>")


else:
    print("<head>")
    print("<script>")
    print("alert('Login Failed | Invalid Incredentials')")                        #............................Alert.......................
    print("</script>")
    print("<head>")
    print("<meta http-equiv='refresh' content='0; url=adminlogin.html'/>")

con.close()
