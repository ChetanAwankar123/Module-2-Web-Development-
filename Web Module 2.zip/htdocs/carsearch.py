#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()

cnm=form.getvalue("cnm")

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

curs.execute("select * from cars where company='%s' ;" %(cnm))
data=curs.fetchall()

if data:

    for rec in data:
        print("<html>")
        print("<head>")
        
        print("Company : %s" %rec[0])  
        print("<br> Model : %s" %rec[1])
        print("<br> Car Type : %s" %rec[2])
        print("<br> Launching : %s" %rec[3])  
        print("<br> Price : %s" %rec[4])  
        print("<br> Color : %s" %rec[5])  
        print("<br> Fuel Type : %s" %rec[6])  
        print("<br> Owner Type : %s" %rec[8]) 
        print("<br>")

        print("<br><hr><hr><br>")

        print("<head>")
        print("</html>")


else:
    print("<h2> No Record Found......... </h2>")

con.close()