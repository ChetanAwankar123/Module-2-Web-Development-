#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

curs.execute("select * from customer;")
data=curs.fetchall()
# print(data)

print("<html>")

print("<head>")
print("<link rel='stylesheet' type='text/css' href='style_2.css'>")
print("<link rel='stylesheet' type='text/css' href='bootstrap.min.css'>")
print("</head>")

print("<body>")
print("<div class='heading'> </div> <div class='image'></div></div>")
print("<div class='container'>")
print("<h1 style='color: rgb(98, 0, 255)'><i>CHETAN AUTOMOBILES</i></h1><br>")
print("<h2 style='color: chartreuse ;'> CUSTOMER LIST</h2><br>")
print("<table class='table table-bordered table-hover'> <tr style='background-color: pink'>")  
print("<th> Customer Name ")  
print("<th> Mobile ")  

for rec in data:  
    print("<tr>")
    print("<td><b>%s</b>" %rec[0])        
    print("<td><b>%s</b>" %rec[2])        
    print("<tr>")   

print("<a href ='/' button class='mr-1 text-blue-400'><b>Home &nbsp; </b></button></a> | <a href ='adminlogin.html' button class='mr-6 text-blue-400'><b> &nbsp; Logout</b></button></a>")

print("</div>")
print("</body>")
print("</html>")

con.close()