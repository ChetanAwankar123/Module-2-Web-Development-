#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()

cnm=form.getvalue("cnm")
cid=form.getvalue("cid")
mob=form.getvalue("mob")
cty=form.getvalue("cty")
enqcar=form.getvalue("enqcar")


con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

try:
    curs.execute("insert into customer values('%s','%s',%d,'%s','%s');" %(cnm,cid,int(mob),cty,enqcar))
    con.commit()
    
    print("<head>")    
    print("<script>")
    print("alert('Customer Registration Sucessful....')")                       #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=options.html'/>")

except:
    print("<head>")
    print("<script>")
    print("alert('Registration Failed....')")                        #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=custreg.html'/>")

con.close()