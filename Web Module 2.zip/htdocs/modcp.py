#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()

cpnm=form.getvalue("cpnm")
mdl=form.getvalue("mdl")
clr=form.getvalue("clr")
cp=int(form.getvalue("cp"))
mp=int(form.getvalue("mp"))

# print(cpnm,mdl,clr,cp,mp)

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

# curs.execute("select * from cars;")
curs.execute("select * from cars where company= '%s' and model= '%s' and color= '%s' and price= %d;" %(cpnm,mdl,clr,cp))
data=curs.fetchall()
# print(data)

if data:
    curs.execute("update cars set price=%d where company='%s' and model='%s' and color='%s' and price=%d" %(mp,cpnm,mdl,clr,cp))
    con.commit()
    print("<head>")    
    print("<script>")
    print("alert('Car Price Updated Sucessful....')")                       #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=options.html'/>")

else:
    print("<head>")    
    print("<script>")
    print("alert('Invalid Input....')")                       #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=modcp.html'/>")





# con.close()