#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()

id=form.getvalue("id")
cnm=form.getvalue("cnm")
mob=int(form.getvalue("mob"))
enq=form.getvalue("enq")

# print(id,cnm,mob,enq)

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

curs.execute("select * from customer where custid= '%s';" %id)
data=curs.fetchall()
# print(data)

if data:
    curs.execute("update customer set custnm='%s', mobile=%d, company='%s' where custid='%s' ;" %(cnm,mob,enq,id))
    con.commit()
    print("<head>")    
    print("<script>")
    print("alert('Customer Details Updated Sucessful....')")                       #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=options.html'/>")

else:
    print("<head>")    
    print("<script>")
    print("alert('Invalid Customer ID....')")                       #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=modcust.html'/>")

con.close()