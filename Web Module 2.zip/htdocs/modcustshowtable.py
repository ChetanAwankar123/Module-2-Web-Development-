#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()
    
# print("<link href='https://unpkg.com/tailwindcss@^1/dist/tailwind.min.css' rel='stylesheet'")
print("<link rel='stylesheet' href='bootstrap.min.css'>")
print("<div class='container'>")

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

curs.execute(" select * from customer order by custnm; ")
data=curs.fetchall()

print("<table class='table table-bordered table-hover'> <tr style='background-color: pink'>")  
print("<th> Customer Name ")  
print("<th> Customer ID ")  
print("<th> Mobile ")
print("<th> City ")  
print("<th> Enquired ")  

for rec in data:  
    print("<tr>")
    print("<td>%s" %rec[0])        
    print("<td>%s" %rec[1])        
    print("<td>%s" %rec[2])        
    print("<td>%s" %rec[3])        
    print("<td>%s" %rec[4])        
           
    print("<tr>")    

print("</table> <br><br>")

con.close()