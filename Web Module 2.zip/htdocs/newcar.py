#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()

cnm=form.getvalue("cnm")
mdl=form.getvalue("mdl")
ctype=form.getvalue("ctype")
launch=form.getvalue("launch")
price=form.getvalue("price")
color=form.getvalue("color")
fuel=form.getvalue("fuel")
Xn=form.getvalue("Xn")
owner=form.getvalue("owner")

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

try:
    curs.execute("insert into cars values('%s','%s','%s',%d,%d,'%s','%s','%s','%s');" %(cnm,mdl,ctype,int(launch),int(price),color,fuel,Xn,owner))
    con.commit()
    # print("<h3> Registration Sucessful.... </h3>")
    
    print("<head>")    
    print("<script>")
    print("alert('Car Registration Sucessful....')")                       #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=options.html'/>")

except:
    # print("<h3> Registration Failed.... </h3>")
    print("<head>")
    print("<script>")
    print("alert('Registration Failed....')")                        #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=newcar.html'/>")

con.close()