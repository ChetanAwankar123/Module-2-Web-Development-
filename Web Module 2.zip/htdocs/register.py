#!C:\Users\awank\AppData\Local\Programs\Python\Python39\python
import cgi
import mysql.connector

print("Content-type: text/html")
print()

form=cgi.FieldStorage()

name=form.getvalue("nm")
id=form.getvalue("uid")
mobile=form.getvalue("mob")
city=form.getvalue("ct")
adhar=form.getvalue("adh")
psw=form.getvalue("psw")

con=mysql.connector.connect(host="bvjuy66w8antwu2pvbnk-mysql.services.clever-cloud.com", user="u4vdjpyfofdq7jp3", password="nyrxTDWnbbja7EDdwf7V", database="bvjuy66w8antwu2pvbnk")
curs=con.cursor()

try:
    curs.execute("insert into users values('%s','%s','%s','%s','%s','%s');" %(name,id,mobile,city,adhar,psw))
    con.commit()
    
    print("<head>")
    print("<script>")
    print("alert('Registration Sucessful....')")                        #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=adminlogin.html '/>")

except:
    # print("<h3> Registration Failed.... </h3>")
    print("<head>")
    print("<script>")
    print("alert('Registration Failed....')")                        #............................Alert.......................
    print("</script>")
    print("</head>")
    print("<meta http-equiv='refresh' content='0; url=regiester.html '/>")

con.close()